let count = localStorage.getItem("cartCount");

if (count === null) {
    count = 0;
}

const cartCounter = document.querySelector(".cart-count");

cartCounter.textContent = count;

document.querySelector(".add-to-cart").addEventListener("click", () => {

    count++;

    cartCounter.textContent = count;

    localStorage.setItem("cartCount", count);
});